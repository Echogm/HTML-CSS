$(document).ready(function functionName() {

    $(document).ready(function(){
    });

    $('.ninja img').click(function() {
        $(this).hide("slow");
    });

    $('#show').click(function() {
        $(".ninja img").show("slow")
    });
});
